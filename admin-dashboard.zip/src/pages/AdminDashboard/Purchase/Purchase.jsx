const Purchase = () => {
  return (
    <div className="">
      <h3>Purchase</h3>
      <p>
        Lorem ipsum dolor sit, amet consectetur adipisicing elit. Quisquam error
        quia temporibus, harum repudiandae velit consectetur ea ipsam quo amet
        ut facere, delectus, natus ratione. Sapiente eaque et doloremque
        inventore.
      </p>
    </div>
  );
};

export default Purchase;
