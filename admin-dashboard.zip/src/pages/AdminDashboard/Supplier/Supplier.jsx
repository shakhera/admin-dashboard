const Supplier = () => {
  return <div>Supplier</div>;
};

export default Supplier;
