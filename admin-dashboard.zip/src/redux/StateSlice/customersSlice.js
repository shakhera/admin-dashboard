// import { createSlice } from "@reduxjs/toolkit";

// const initialState = {
//   customerList: [],
//   totalCustomers: 0,
// };

// const customersSlice = createSlice({
//   name: "customers",
//   initialState,
//   reducers: {},
// });

// export default customersSlice.reducer;
